# KP Enterprises - Cosmetic Sales Data Analyst Portfolio Project

Welcome to the complete Data Analyst Portfolio Project for **KP Enterprises** (Cosmetic & Personal Care Analytics).

## 📁 Folder Structure
```
KP_Enterprises_Cosmetics_Analytics_Project/
├── data/
│   └── kp_enterprises_cosmetics_sales.csv      # Clean 1200+ Transaction Dataset
├── scripts/
│   ├── kp_sales_analysis.py                   # Python EDA & Visualization Script
│   └── schema_and_queries.sql                  # PostgreSQL / MySQL Schema & Analytical Queries
├── dashboards/
│   └── index.html                             # Interactive Web/Chart.js Executive Dashboard
└── reports/
    └── Executive_Analytics_Report.md          # Business Insights & Management Recommendations
```

## 🛠️ How to Use This Project for LinkedIn / Portfolio
1. **GitHub Upload:** Push this entire directory structure to your GitHub repository.
2. **Python EDA:** Run `python scripts/kp_sales_analysis.py` to generate statistical summaries and visual charts.
3. **SQL Practice:** Import `data/kp_enterprises_cosmetics_sales.csv` into MySQL/PostgreSQL and run `scripts/schema_and_queries.sql`.
4. **Dashboard:** Open `dashboards/index.html` in any web browser to showcase an interactive dashboard.
5. **Power BI / Tableau:** Import `data/kp_enterprises_cosmetics_sales.csv` directly into Power BI to create custom reports!
