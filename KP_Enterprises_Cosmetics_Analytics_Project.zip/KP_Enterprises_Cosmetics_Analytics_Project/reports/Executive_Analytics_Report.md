# KP ENTERPRISES — COSMETIC PRODUCTS SALES ANALYTICS REPORT

## Executive Summary
This document outlines the end-to-end data analytics findings for **KP Enterprises**, a fast-growing cosmetic & personal care brand in India. The analysis covers sales performance across 4 primary product categories (**Skincare, Makeup, Haircare, Fragrance**) and 5 distribution channels (**Nykaa, Amazon, D2C Website, Retail Stores, Myntra**).

---

## 1. Key Performance Indicators (KPIs)
* **Total Net Revenue:** ₹48.52 Lakhs
* **Total Units Sold:** 32,450 Units
* **Average Order Value (AOV):** ₹1,495
* **Return Rate:** 2.1% (Low risk across online marketplaces)
* **Top Performing Region:** North Region (~35% Revenue Share)

---

## 2. Category Level Insights
1. **Skincare (42% Share):** Drives the highest revenue and repeat orders. *Vitamin C Serum* and *Hyaluronic Acid Moisturizer* are core volume drivers.
2. **Makeup (28% Share):** Strong demand on Nykaa and Amazon; high customer acquisition rate among young demographics.
3. **Fragrance (12% Share, Highest AOV):** While unit volume is lower, the Average Order Value is highest (₹2,499), yielding superior profit margins.
4. **Haircare (18% Share):** Steady recurring sales via D2C site subscription channels.

---

## 3. Strategic Recommendations for KP Enterprises
* **Bundle High-Margin SKUs:** Pair top-selling Skincare products (Vitamin C Serum) with Fragrances in festive gift boxes to boost overall AOV above ₹2,000.
* **Regional Focus:** Expand local warehouse operations in West & South regions to improve delivery speed and capture market share.
* **Discount Optimization:** Gradually reduce discounts on flagship Skincare SKUs from 15% to 5% as demand elasticity shows high brand loyalty.

---
*Report prepared by Lead Data Analyst for KP Enterprises.*
