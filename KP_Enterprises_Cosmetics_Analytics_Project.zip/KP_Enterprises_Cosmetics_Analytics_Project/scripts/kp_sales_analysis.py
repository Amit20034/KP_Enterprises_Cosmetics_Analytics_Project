import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import seaborn as sns

# Load Sales Data
print("Loading KP Enterprises Cosmetic Sales Dataset...")
df = pd.read_csv('../data/kp_enterprises_cosmetics_sales.csv')

# 1. Preprocessing & Clean Up
df['Date'] = pd.to_datetime(df['Date'])
df['Year_Month'] = df['Date'].dt.to_period('M')

# Exclude returned items for revenue calculations
valid_sales = df[df['Return_Status'] == 'No'].copy()

# 2. Executive KPI Calculation
total_gross_rev = valid_sales['Gross_Revenue_INR'].sum()
total_net_rev = valid_sales['Net_Revenue_INR'].sum()
total_units = valid_sales['Units_Sold'].sum()
aov = valid_sales['Net_Revenue_INR'].mean()
total_orders = len(valid_sales)

print("\n" + "="*50)
print("      KP ENTERPRISES - EXECUTIVE SUMMARY")
print("="*50)
print(f"Total Gross Revenue : ₹{total_gross_rev:,.2f}")
print(f"Total Net Revenue   : ₹{total_net_rev:,.2f}")
print(f"Total Orders Count  : {total_orders:,}")
print(f"Total Units Sold    : {total_units:,}")
print(f"Average Order Value : ₹{aov:,.2f}")
print("="*50 + "\n")

# 3. Category Insights
cat_summary = valid_sales.groupby('Category').agg(
    Net_Revenue=('Net_Revenue_INR', 'sum'),
    Units_Sold=('Units_Sold', 'sum'),
    Avg_Discount=('Discount_Percent', 'mean')
).sort_values(by='Net_Revenue', ascending=False)

print("CATEGORY PERFORMANCE:")
print(cat_summary)
print("\n")

# 4. Regional Insights
region_summary = valid_sales.groupby('Region').agg(
    Net_Revenue=('Net_Revenue_INR', 'sum'),
    Units_Sold=('Units_Sold', 'sum')
).sort_values(by='Net_Revenue', ascending=False)

print("REGIONAL PERFORMANCE:")
print(region_summary)

# 5. Visualizations
plt.style.use('seaborn-v0_8-darkgrid')
fig, axes = plt.subplots(2, 2, figsize=(15, 10))

# Subplot 1: Revenue by Category
sns.barplot(data=cat_summary.reset_index(), x='Category', y='Net_Revenue', ax=axes[0, 0], palette='Blues_r')
axes[0, 0].set_title('Net Revenue by Category (INR)', fontsize=12, fontweight='bold')
axes[0, 0].set_ylabel('Net Revenue (₹)')

# Subplot 2: Regional Revenue Share
axes[0, 1].pie(region_summary['Net_Revenue'], labels=region_summary['Region'], autopct='%1.1f%%', colors=['#2b5c8f', '#4682b4', '#6baed6', '#9ecae1'], startangle=140)
axes[0, 1].set_title('Regional Revenue Share', fontsize=12, fontweight='bold')

# Subplot 3: Sales Channel Distribution
channel_summary = valid_sales.groupby('Channel')['Net_Revenue_INR'].sum().reset_index()
sns.barplot(data=channel_summary, x='Channel', y='Net_Revenue_INR', ax=axes[1, 0], palette='Viridis')
axes[1, 0].set_title('Revenue by Sales Channel', fontsize=12, fontweight='bold')
axes[1, 0].set_ylabel('Net Revenue (₹)')

# Subplot 4: Monthly Revenue Trend
monthly_trend = valid_sales.groupby('Year_Month')['Net_Revenue_INR'].sum().reset_index()
monthly_trend['Year_Month_Str'] = monthly_trend['Year_Month'].astype(str)
axes[1, 1].plot(monthly_trend['Year_Month_Str'], monthly_trend['Net_Revenue_INR'], marker='o', color='#2b5c8f', linewidth=2.5)
axes[1, 1].set_title('Monthly Revenue Growth Trend', fontsize=12, fontweight='bold')
axes[1, 1].set_xticklabels(monthly_trend['Year_Month_Str'], rotation=45, ha='right')
axes[1, 1].set_ylabel('Net Revenue (₹)')

plt.tight_layout()
plt.savefig('../reports/sales_analytics_summary.png', dpi=300)
print("\nSummary visualization saved to 'reports/sales_analytics_summary.png'")
