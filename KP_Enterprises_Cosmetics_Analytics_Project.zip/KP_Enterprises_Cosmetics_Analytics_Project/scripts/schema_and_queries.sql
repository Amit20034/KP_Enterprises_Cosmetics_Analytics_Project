-- KP Enterprises Cosmetic Product Sales Database Schema & Analytics Queries

-- 1. Create Table Schema
CREATE TABLE cosmetic_sales (
    transaction_id VARCHAR(50) PRIMARY KEY,
    transaction_date DATE NOT NULL,
    category VARCHAR(50) NOT NULL,
    product_name VARCHAR(100) NOT NULL,
    region VARCHAR(50) NOT NULL,
    channel VARCHAR(50) NOT NULL,
    customer_type VARCHAR(20) NOT NULL,
    units_sold INT NOT NULL,
    unit_price_inr DECIMAL(10, 2) NOT NULL,
    gross_revenue_inr DECIMAL(10, 2) NOT NULL,
    discount_percent DECIMAL(5, 2) DEFAULT 0.00,
    net_revenue_inr DECIMAL(10, 2) NOT NULL,
    return_status VARCHAR(10) DEFAULT 'No'
);

-- 2. Query 1: Overall Business KPIs
SELECT 
    SUM(net_revenue_inr) AS total_net_revenue,
    SUM(units_sold) AS total_units_sold,
    AVG(net_revenue_inr) AS average_order_value,
    COUNT(DISTINCT transaction_id) AS total_orders
FROM cosmetic_sales
WHERE return_status = 'No';

-- 3. Query 2: Category Breakdown & Profitability Contribution
SELECT 
    category,
    SUM(net_revenue_inr) AS category_revenue,
    SUM(units_sold) AS category_units,
    ROUND(AVG(discount_percent), 2) AS avg_discount_given,
    ROUND((SUM(net_revenue_inr) * 100.0 / (SELECT SUM(net_revenue_inr) FROM cosmetic_sales WHERE return_status = 'No')), 2) AS revenue_contribution_pct
FROM cosmetic_sales
WHERE return_status = 'No'
GROUP BY category
ORDER BY category_revenue DESC;

-- 4. Query 3: Top 5 Best-Selling Products by Revenue
SELECT 
    product_name,
    category,
    SUM(units_sold) AS total_units,
    SUM(net_revenue_inr) AS total_revenue
FROM cosmetic_sales
WHERE return_status = 'No'
GROUP BY product_name, category
ORDER BY total_revenue DESC
LIMIT 5;

-- 5. Query 4: Monthly Revenue & Growth Trend
WITH monthly_sales AS (
    SELECT 
        DATE_TRUNC('month', transaction_date) AS sales_month,
        SUM(net_revenue_inr) AS current_month_revenue
    FROM cosmetic_sales
    WHERE return_status = 'No'
    GROUP BY DATE_TRUNC('month', transaction_date)
)
SELECT 
    sales_month,
    current_month_revenue,
    LAG(current_month_revenue, 1) OVER (ORDER BY sales_month) AS previous_month_revenue,
    ROUND(((current_month_revenue - LAG(current_month_revenue, 1) OVER (ORDER BY sales_month)) * 100.0 / NULLIF(LAG(current_month_revenue, 1) OVER (ORDER BY sales_month), 0)), 2) AS mom_growth_pct
FROM monthly_sales
ORDER BY sales_month;
